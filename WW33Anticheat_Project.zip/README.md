# WW33Anticheat

WW33Anticheat is a powerful, open-source Minecraft anti-cheat supporting versions 1.7 to 1.20. It includes 90+ detection algorithms, multithreaded design, and advanced admin tools.

## Features
- Detects scaffold, fly, timer, autoclicker, and more.
- Real-time admin monitoring with `/watch` and `/overview`.
- Fully configurable through `config.yml`.

## Installation
1. Place the `WW33Anticheat.jar` file in your server's plugins folder.
2. Restart the server to generate the configuration files.
3. Adjust settings in `config.yml` to suit your server.

## Commands
- `/ww33ac` - Displays general command info.
- `/ww33ac alerts` - Toggles alerts.
- `/ww33ac logs <player>` - Displays logs for a specific player.
- `/ww33ac ping <player>` - Displays ping info.
