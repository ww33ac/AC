package com.example.ww33anticheat;

public class WW33Anticheat {
    public static void main(String[] args) {
        System.out.println("WW33Anticheat plugin loaded.");
    }
}
